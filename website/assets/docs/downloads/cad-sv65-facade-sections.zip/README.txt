CAD Facade Section drawings library for system SV65.
Double click to import to AutoCAD.